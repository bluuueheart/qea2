/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file            : main.c
 * @brief           : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dac.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"
#include "fsmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "../../Drivers/BSP/LCD/lcd.h" // 确保LCD驱动路径正确
#include <stdio.h> // 用于 sprintf
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// ADS1292 SPI Commands and Register Addresses
#define ADS1292_CMD_WAKEUP  0x02  // Wake-up from standby mode
#define ADS1292_CMD_STANDBY 0x04  // Enter standby mode
#define ADS1292_CMD_RESET   0x06  // Reset the device
#define ADS1292_CMD_START   0x08  // Start/restart (synchronize) conversions
#define ADS1292_CMD_STOP    0x0A  // Stop conversion
#define ADS1292_CMD_RDATAC  0x10  // Read data continuous mode
#define ADS1292_CMD_SDATAC  0x11  // Stop read data continuous mode
#define ADS1292_CMD_RDATA   0x12  // Read data by command
#define ADS1292_CMD_RREG    0x20  // Read from REGn
#define ADS1292_CMD_WREG    0x40  // Write to REGn

#define ADS1292_REG_ID      0x00  // ID Register address
#define ADS1292_REG_CONFIG1 0x01  // CONFIG1 Register address
#define ADS1292_REG_CONFIG2 0x02  // CONFIG2 Register address


// ADS1292 Chip Select Pin - 您需要根据您的CubeMX配置来定义这�?????
// 确保这个定义与您为ADS1292 CS引脚配置的GPIO端口和引脚号�?????�?????
#define ADS1292_CS_GPIO_Port GPIOC
#define ADS1292_CS_Pin       GPIO_PIN_4

// ADS1292 /PWDN/RESET Pin (连接到模块的 J2 Pin 2 - ADS_PWDN)
// *** 请确保您在CubeMX中将此引脚配置为GPIO输出模式 ***
// *** 并在此处修改为实际连接的STM32 GPIO引脚 ***
#define ADS1292_PWDN_GPIO_Port GPIOA // <<--- 示例：请修改为您的实际引�?????
#define ADS1292_PWDN_Pin       GPIO_PIN_1  // <<--- 示例：请修改为您的实际引�?????
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t ads1292_device_id_value;
uint8_t ads1292_config1_default;
uint8_t ads1292_config1_written = 0x06; // 要写入CONFIG1的测试�?? (例如，改变数据�?�率 DR[2:0]=110 -> 8kSPS)
uint8_t ads1292_config1_readback;
uint8_t ads1292_config2_readback;

char ads1292_display_str1[40];
char ads1292_display_str2[40];
char ads1292_display_str3[40];

// Variables re-added to satisfy linker for gpio.c's HAL_GPIO_EXTI_Callback
uint8_t Sign_function = 0;
uint16_t wave_table_i = 0;
uint8_t Sign_dacToggleWave = 0;
uint16_t wave_frequency = 1000;
char show_string_wave_frequency[8] = {"1kHz"};
uint16_t zoomInMultiple = 1;
uint8_t Sign_stop = 0;
uint8_t valueData_type = 0;
uint8_t Sign_stringUpdate = 1;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void ADS1292_Send_Command(uint8_t command);
void ADS1292_Write_Register(uint8_t address, uint8_t value);
uint8_t ADS1292_Read_Register(uint8_t address);
void ADS1292_Init_Sequence(void);
#if (__CORTEX_M >= 0x03)
void DWT_Delay_Init(void);
void DWT_Delay_us(volatile uint32_t microseconds);
#endif
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#if (__CORTEX_M >= 0x03)
volatile uint32_t DWT_Dummy_Var_For_INIT_章节; // Renamed to avoid conflict if defined elsewhere
void DWT_Delay_Init(void) {
    if (!(CoreDebug->DEMCR & CoreDebug_DEMCR_TRCENA_Msk)) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk; // Enable TRC
        DWT_Dummy_Var_For_INIT_章节 = DWT->CYCCNT;     // Make sure CYCCNT is running
        DWT->CYCCNT = 0;                               // Reset the cycle counter
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;           // Enable cycle counter
    }
}

void DWT_Delay_us(volatile uint32_t microseconds) {
    if (DWT_CTRL_CYCCNTENA_Msk & DWT->CTRL) { // Check if DWT counter is enabled
        uint32_t clk_cycle_start = DWT->CYCCNT;
        uint32_t cycles_needed = microseconds * (HAL_RCC_GetHCLKFreq() / 1000000);
        while ((DWT->CYCCNT - clk_cycle_start) < cycles_needed);
    } else {
        // Fallback or error: DWT not initialized or enabled
        // For short delays, you can use NOPs, but this is very approximate
        for (volatile uint32_t i = 0; i < microseconds * (HAL_RCC_GetHCLKFreq() / 1000000 / 10); ++i) {
            __NOP();
        }
    }
}
#else
// Fallback for non-DWT cores or if DWT is not preferred for some reason
void DWT_Delay_us(volatile uint32_t microseconds) {
    // This is a rough, blocking loop. Not accurate.
    // Consider HAL_Delay(1) for millisecond-level delays if microsecond precision isn't strictly required here.
    for(volatile uint32_t i = 0; i < microseconds * (HAL_RCC_GetHCLKFreq() / 10000000); i++);
}
#endif
/**
 * @brief Sends a single-byte command to the ADS1292.
 * @param command: The command byte to send.
 */
void ADS1292_Send_Command(uint8_t command)
{
    HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_RESET);
    // Optional: DWT_Delay_us(1); // Short delay for CS setup if needed
    HAL_SPI_Transmit(&hspi1, &command, 1, 100);
    HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_SET);
    // Optional: DWT_Delay_us(1); // t_SCSKH: CSn high time between commands minimum 4*tSCLK
                               // Often, subsequent logic provides enough delay. If sending commands
                               // very rapidly back-to-back, a small HAL_Delay(1) might be safer.
}

/**
 * @brief Writes a value to a single ADS1292 register.
 * @param address: Register address.
 * @param value: Value to write.
 */
void ADS1292_Write_Register(uint8_t address, uint8_t value)
{
    uint8_t tx_buffer[3];
    tx_buffer[0] = ADS1292_CMD_WREG | address;
    tx_buffer[1] = 0x00; // Number of registers to write - 1 (0x00 for 1 register)
    tx_buffer[2] = value;

    HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_RESET);
    // Optional: DWT_Delay_us(1);
    HAL_SPI_Transmit(&hspi1, tx_buffer, 3, 100);
    HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_SET);
}

/**
 * @brief Reads a single ADS1292 register.
 * @param address: Register address.
 * @retval Register value, or error code.
 */
uint8_t ADS1292_Read_Register(uint8_t address)
{
    uint8_t tx_cmd_buffer[2];
    uint8_t rx_buffer[1] = {0}; // Initialize
    HAL_StatusTypeDef spi_status_tx, spi_status_rx;

    tx_cmd_buffer[0] = ADS1292_CMD_RREG | address;
    tx_cmd_buffer[1] = 0x00; // Number of registers to read - 1 (0x00 for 1 register)

    HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_RESET);
    // Optional: DWT_Delay_us(1);

    spi_status_tx = HAL_SPI_Transmit(&hspi1, tx_cmd_buffer, 2, 100);

    if (spi_status_tx != HAL_OK)
    {
        HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_SET);
        return 0xFF; // SPI transmit error
    }

    // To read data, we send dummy clock pulses.
    // The original code's HAL_SPI_TransmitReceive is fine here.
    uint8_t dummy_byte = 0x00; // Value of dummy byte doesn't matter
    spi_status_rx = HAL_SPI_TransmitReceive(&hspi1, &dummy_byte, rx_buffer, 1, 100);

    HAL_GPIO_WritePin(ADS1292_CS_GPIO_Port, ADS1292_CS_Pin, GPIO_PIN_SET);

    if (spi_status_rx != HAL_OK)
    {
        return 0xFE; // SPI receive error
    }

    return rx_buffer[0];
}



/**
 * @brief Performs an initialization sequence for ADS1292.
 * This attempts to follow parts of the "Initial Flow at Power-Up" from the datasheet.
 */
void ADS1292_Init_Sequence(void)
{
#if (__CORTEX_M >= 0x03)
    // DWT_Delay_Init(); // Call this ONCE at the beginning of main() if using DWT_Delay_us
#endif

    // 1. Power-Down Pin (/PWDN) Reset Sequence
    // Ensure /PWDN is initially high (device not in power-down by pin)
    HAL_GPIO_WritePin(ADS1292_PWDN_GPIO_Port, ADS1292_PWDN_Pin, GPIO_PIN_SET);
    HAL_Delay(5);

    // Pulse /PWDN low to reset
    HAL_GPIO_WritePin(ADS1292_PWDN_GPIO_Port, ADS1292_PWDN_Pin, GPIO_PIN_RESET);
    HAL_Delay(5);  // t_PWDN_LW: min 18 * t_CLK (~8.8us with 2.048MHz internal CLK). 5ms is ample.

    // Bring /PWDN high to enable the device
    HAL_GPIO_WritePin(ADS1292_PWDN_GPIO_Port, ADS1292_PWDN_Pin, GPIO_PIN_SET);
    // Wait for t_RST (Power-On Reset time, typically ~128ms-150ms)
    HAL_Delay(200); // Sufficient time for oscillator and POR. (Your 1000ms was also very safe)

    // 2. Send RESET command (optional after /PWDN reset, but good practice)
    ADS1292_Send_Command(ADS1292_CMD_RESET);
    // Wait for RESET command to complete (datasheet: min 18 t_CLK cycles, ~8.8us).
    HAL_Delay(2); // 2ms is plenty (your 10ms was fine)

    // 3. Stop Continuous Data Mode (SDATAC)
    ADS1292_Send_Command(ADS1292_CMD_SDATAC);
    HAL_Delay(2); // Short delay (your 5ms was fine)
    ADS1292_Send_Command(ADS1292_CMD_STOP);
    HAL_Delay(2);

    // 4. Initial Configuration (Example: CONFIG2 for internal reference)
    ADS1292_Write_Register(ADS1292_REG_CONFIG2, 0xA0); // Enable internal reference, etc.
    HAL_Delay(1); // Short delay after write.
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
#if (__CORTEX_M >= 0x03)
  DWT_Delay_Init(); // Initialize DWT counter once if you use DWT_Delay_us
#endif
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_FSMC_Init();
  MX_DAC_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_SPI3_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */

    lcd_init();
    lcd_display_dir(0);
    lcd_clear(WHITE);

    ADS1292_Init_Sequence();

    // 1. Read ID Register
    uint8_t id1 = ADS1292_Read_Register(ADS1292_REG_ID);
    HAL_Delay(10); // SPI 读取之间的延�??
    uint8_t id2 = ADS1292_Read_Register(ADS1292_REG_ID);
    HAL_Delay(10);

    // 2. Read CONFIG1 Register's default value
    ads1292_config1_default = ADS1292_Read_Register(ADS1292_REG_CONFIG1);
    HAL_Delay(1);

    // 3. Write a test value to CONFIG1 Register
    ADS1292_Write_Register(ADS1292_REG_CONFIG1, ads1292_config1_written);
    HAL_Delay(1);

    // 4. Read back CONFIG1 to verify write
    ads1292_config1_readback = ADS1292_Read_Register(ADS1292_REG_CONFIG1);
    HAL_Delay(1);

    // 5. (Optional) Restore CONFIG1 to a known default (e.g., 0x02 for 500SPS)
    ADS1292_Write_Register(ADS1292_REG_CONFIG1, 0x02);
    HAL_Delay(1);

    // 6. Read CONFIG2 (should be 0xA0 as written in Init_Sequence)
    ads1292_config2_readback = ADS1292_Read_Register(ADS1292_REG_CONFIG2);
    ads1292_device_id_value = id1;
    if (ads1292_device_id_value == 0xFF || ads1292_device_id_value == 0xFE) {
        sprintf(ads1292_display_str1, "ID: SPI Err(0x%02X)", ads1292_device_id_value);
    } else {
        uint8_t dev_type_nibble = (ads1292_device_id_value >> 4) & 0x0F;
        const char* chip_model_str = "Unknown";
        if (dev_type_nibble == 0x09) {
            chip_model_str = "ADS1292";
        } else if (dev_type_nibble == 0x07) {
            chip_model_str = "ADS1292R";
        }
			if (id1 == id2 && id1 != 0xFF && id1 != 0xFE && id1 != 0x00) {
				ads1292_device_id_value = id1;
				sprintf(ads1292_display_str1, "ADS1292 ID: 0x%02X", ads1292_device_id_value);
			} else {
				ads1292_device_id_value = 0xFF;
				sprintf(ads1292_display_str1, "ID Read Fail: 0x%02X", id1);  // 或显�?? id1/id2 均可
			}
    }
    lcd_show_string(10, 20, 280, 16, 16, ads1292_display_str1, BLUE);

    sprintf(ads1292_display_str2, "C1Def:0x%02X Wr:0x%02X Rb:0x%02X",
            ads1292_config1_default,
            ads1292_config1_written,
            ads1292_config1_readback);
    lcd_show_string(10, 40, 280, 16, 16, ads1292_display_str2, BLUE);

    sprintf(ads1292_display_str3, "C2Rb:0x%02X (Exp:0xA0)", ads1292_config2_readback);
    lcd_show_string(10, 60, 280, 16, 16, ads1292_display_str3, BLUE);

    uint8_t id_loop = ADS1292_Read_Register(ADS1292_REG_ID); // You had this test line
    lcd_show_string(10, 100, 280, 16, 16, "ID loop:0x", RED);
    lcd_show_xnum(100, 100, id_loop, 2, 16, 0, RED); // Adjusted position

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    while (1)
    {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
        HAL_Delay(1000);
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
// Variables re-added to satisfy linker for gpio.c's HAL_GPIO_EXTI_Callback
// These are not actively used by the main() loop's ID display logic anymore.
// uint8_t Sign_function = 0; // Already in PV section
// uint16_t wave_table_i = 0; // Already in PV section
// uint8_t Sign_dacToggleWave = 0; // Already in PV section
// uint16_t wave_frequency = 1000; // Already in PV section
// char show_string_wave_frequency[8] = {"1kHz"}; // Already in PV section
// uint16_t zoomInMultiple = 1; // Already in PV section
// uint8_t Sign_stop = 0; // Already in PV section
// uint8_t valueData_type = 0; // Already in PV section
// uint8_t Sign_stringUpdate = 1; // Already in PV section
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
