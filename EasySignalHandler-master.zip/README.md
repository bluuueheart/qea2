# 简易示波器与信号发生器

#### 介绍
使用CubeIDE，基于正点原子探索者开发板(STM32F407)开发的简易信号发生器和示波器，能够实现自发自采，拥有调频、测频、频域图像、幅值测量等功能。

#### 使用说明
工程文件夹名为Signal_Impact

#### 参与贡献
个人独立开发

#### 演示视频
https://www.bilibili.com/video/BV16dieYFEW2/?vd_source=5876e4ffc8c2f35c3637b3fbf403c7a6